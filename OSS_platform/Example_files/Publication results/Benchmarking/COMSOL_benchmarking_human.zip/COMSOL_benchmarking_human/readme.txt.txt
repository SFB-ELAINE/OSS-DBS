The model was created in COMSOL Multiphysics 5.5.
The model was saved only with the initial mesh and without results.
Make sure to enable Refine 2 and Refine 1 in Mesh directory.
Dielectric properties are set to 520 Hz according to Gabriel et al.
For Results/Export/Data1 and Results/Datasets/Cut_Point_3D_1 make sure you are in the direcctory of the project.
