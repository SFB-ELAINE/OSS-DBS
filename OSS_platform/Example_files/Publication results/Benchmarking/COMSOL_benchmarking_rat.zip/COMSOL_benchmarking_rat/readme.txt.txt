The model was created in COMSOL Multiphysics 5.5.
The model was saved without mesh and results to spare the size.
Dielectric properties are set to 520 Hz according to Gabriel et al.
For Results/Export/Data1 and Results/Datasets/Cut_Point_3D_2 make sure you are in the direcctory of the project.
